import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Step 1: Let the user input names until "quit" is entered
        ArrayList<String> contestants = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        String name;
        System.out.println("Enter names (type 'quit' to stop):");
        do {
            name = scanner.nextLine();
            if (!name.equals("quit")) {
                contestants.add(name);
            }
        } while (!name.equals("quit"));

        // Step 2: Print list of all contestants
        System.out.println("List of contestants:");
        for (String contestant : contestants) {
            System.out.println(contestant);
        }

        // Step 3: Generate random number and declare the first winner
        Random random = new Random();
        int randomIndex = random.nextInt(contestants.size());
        String firstWinner = contestants.get(randomIndex);
        System.out.println("The first winner is: " + firstWinner);

        // Step 4: Remove the first winner from the list
        contestants.remove(randomIndex);

        // Step 5: Generate random number again and declare the second winner
        randomIndex = random.nextInt(contestants.size());
        String secondWinner = contestants.get(randomIndex);
        System.out.println("The second winner is: " + secondWinner);
    }
}

