import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Step 2: Create an ArrayList of animals and name the variable as landAnimals
        ArrayList<Animal> landAnimals = new ArrayList<>();

        // Step 3: Create a few animal objects like cheetah, reindeer, gazelle, etc and add them to the landAnimals arrayList
        Animal cheetah = new Animal("Panda", 24.8);
        Animal reindeer = new Animal("Lion", 40.5);
        Animal gazelle = new Animal("Elephant", 26.0);

        landAnimals.add(panda);
        landAnimals.add(lion);
        landAnimals.add(elephant);

        // Step 4: Iterate over the landAnimal list and print it
        System.out.println("List of Land Animals:");
        for (Animal animal : landAnimals) {
            System.out.println("Name: " + animal.getName() + ", Speed: " + animal.getSpeed() + " m/s");
        }

        // Step 5: Among the land animals try to find the fastest animal
        Animal fastestAnimal = findFastestAnimal(landAnimals);
        System.out.println("The fastest animal is: " + fastestAnimal.getName() + " with a speed of " + fastestAnimal.getSpeed() + " m/s");
    }

    // Helper method to find the fastest animal
    public static Animal findFastestAnimal(ArrayList<Animal> animals) {
        Animal fastestAnimal = null;
        double maxSpeed = Double.MIN_VALUE;

        for (Animal animal : animals) {
            if (animal.getSpeed() > maxSpeed) {
                maxSpeed = animal.getSpeed();
                fastestAnimal = animal;
            }
        }

        return fastestAnimal;
    }
}

